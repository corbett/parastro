#!/usr/bin/python
# Produces a random number for each particle in the additional attribute format
# number of particles is the first and only argument of the script.
# Usage: genRandomAttribute.py 1001 > randomAttribute.ran
import sys,random
num_particles=int(sys.argv[1])
print num_particles
for i in range(num_particles):
    print random.random()

